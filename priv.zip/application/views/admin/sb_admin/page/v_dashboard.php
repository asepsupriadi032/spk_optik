<center>
<img src="<?php echo base_url('assets/user')?>/img/logo.png" alt="" width="250" height= "250" align= "center"/>

<h1 class="masthead mb-0" style="margin-top: 10px !important;padding: 20px; text-align: center;"><b>Selamat Datang di Optik CSL </b></h1>

<h2 align="center"> Jalan Salemba Raya 28 Jakarta </h2>
</center>